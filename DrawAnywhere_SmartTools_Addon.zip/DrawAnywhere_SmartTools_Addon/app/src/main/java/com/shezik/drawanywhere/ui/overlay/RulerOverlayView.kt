package com.shezik.drawanywhere.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class RulerOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val rulerPaint = Paint().apply {
        color = 0xCCFFFFFF.toInt()
        style = Paint.Style.FILL
    }

    private val linePaint = Paint().apply {
        color = 0xFF222222.toInt()
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = 0xFF222222.toInt()
        textSize = 26f
        isAntiAlias = true
    }

    private var rulerWidth = 700f
    private var rulerHeight = 130f

    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var lastAngle = 0f
    private var isDragging = false

    var onPositionChanged: (() -> Unit)? = null

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(rulerWidth.toInt(), rulerHeight.toInt())
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.rawX
                lastTouchY = event.rawY
                isDragging = true
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount == 2) {
                    lastAngle = getAngle(event)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 2) {
                    val currentAngle = getAngle(event)
                    rotation += (currentAngle - lastAngle)
                    lastAngle = currentAngle
                    invalidate()
                    onPositionChanged?.invoke()
                } else if (isDragging && event.pointerCount == 1) {
                    val dx = event.rawX - lastTouchX
                    val dy = event.rawY - lastTouchY
                    translationX += dx
                    translationY += dy
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    onPositionChanged?.invoke()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun getAngle(event: MotionEvent): Float {
        val dx = (event.getX(0) - event.getX(1)).toDouble()
        val dy = (event.getY(0) - event.getY(1)).toDouble()
        return Math.toDegrees(atan2(dy, dx)).toFloat()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, rulerWidth, rulerHeight, rulerPaint)
        canvas.drawRect(0f, 0f, rulerWidth, rulerHeight, linePaint)

        var currentX = 50f
        var cmCounter = 1
        while (currentX < rulerWidth - 40f) {
            canvas.drawLine(currentX, 0f, currentX, 35f, linePaint)
            canvas.drawText(cmCounter.toString(), currentX - 8f, 65f, textPaint)

            for (i in 1..4) {
                val subX = currentX + (i * 10f)
                if (subX < rulerWidth) {
                    canvas.drawLine(subX, 0f, subX, 18f, linePaint)
                }
            }
            currentX += 50f
            cmCounter++
        }
    }

    fun getRulerEdgeLine(): LineSegment {
        val rad = Math.toRadians(rotation.toDouble())
        val cx = x + translationX + rulerWidth / 2f
        val cy = y + translationY + rulerHeight / 2f

        val halfW = rulerWidth / 2f
        val halfH = rulerHeight / 2f

        // Alt kenarın sol ve sağ köşelerinin döndürülmüş koordinatları
        val p1x = cx + (-halfW * cos(rad) - halfH * sin(rad)).toFloat()
        val p1y = cy + (-halfW * sin(rad) + halfH * cos(rad)).toFloat()

        val p2x = cx + (halfW * cos(rad) - halfH * sin(rad)).toFloat()
        val p2y = cy + (halfW * sin(rad) + halfH * cos(rad)).toFloat()

        return LineSegment(PointF(p1x, p1y), PointF(p2x, p2y))
    }

    data class LineSegment(val start: PointF, val end: PointF)
}
