package com.shezik.drawanywhere.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun FloatingToolbarView(
    onSmartShapeToggled: (Boolean) -> Unit,
    onRulerToggled: (Boolean) -> Unit,
    onUndoClicked: () -> Unit,
    onClearClicked: () -> Unit
) {
    var isSmartShapeActive by remember { mutableStateOf(true) }
    var isRulerVisible by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color(0xDD1E1E1E),
        shadowElevation = 8.dp,
        modifier = Modifier.padding(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            // Akıllı Şekil Tanıma Butonu
            IconButton(
                onClick = {
                    isSmartShapeActive = !isSmartShapeActive
                    onSmartShapeToggled(isSmartShapeActive)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.AutoFixHigh,
                    contentDescription = "Akıllı Şekil Modu",
                    tint = if (isSmartShapeActive) Color(0xFF4CAF50) else Color.White.copy(alpha = 0.6f)
                )
            }

            // Dijital Cetvel Butonu
            IconButton(
                onClick = {
                    isRulerVisible = !isRulerVisible
                    onRulerToggled(isRulerVisible)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Straighten,
                    contentDescription = "Dijital Cetvel",
                    tint = if (isRulerVisible) Color(0xFF2196F3) else Color.White.copy(alpha = 0.6f)
                )
            }

            // Geri Al
            IconButton(onClick = onUndoClicked) {
                Icon(
                    imageVector = Icons.Default.Undo,
                    contentDescription = "Geri Al",
                    tint = Color.White
                )
            }

            // Temizle
            IconButton(onClick = onClearClicked) {
                Icon(
                    imageVector = Icons.Default.Clear,
                    contentDescription = "Temizle",
                    tint = Color(0xFFE57373)
                )
            }
        }
    }
}
