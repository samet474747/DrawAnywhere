package com.shezik.drawanywhere.ui.canvas

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.shezik.drawanywhere.ui.overlay.RulerOverlayView
import kotlin.math.abs
import kotlin.math.hypot

class DrawingCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    data class DrawElement(val path: Path, val paint: Paint)
    private val pathsList = mutableListOf<DrawElement>()
    private val redoList = mutableListOf<DrawElement>()
    private val currentPath = Path()
    
    private val currentPoints = mutableListOf<PointF>()
    private val shapeRecognizer = ShapeRecognizer()

    var activeRuler: RulerOverlayView? = null
    var isSmartShapeEnabled: Boolean = true

    private var currentPaint = Paint().apply {
        color = 0xFFFF0000.toInt()
        strokeWidth = 10f
        style = Paint.Style.STROKE
        isAntiAlias = true
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rawPoint = PointF(event.x, event.y)
        val point = applyRulerSnap(rawPoint)

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                redoList.clear()
                currentPoints.clear()
                currentPoints.add(point)
                
                currentPath.reset()
                currentPath.moveTo(point.x, point.y)
                invalidate()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                currentPoints.add(point)
                currentPath.lineTo(point.x, point.y)
                invalidate()
                return true
            }

            MotionEvent.ACTION_UP -> {
                currentPoints.add(point)
                
                if (isSmartShapeEnabled) {
                    val recognizedShape = shapeRecognizer.recognize(currentPoints)
                    commitRecognizedShape(recognizedShape)
                } else {
                    pathsList.add(DrawElement(Path(currentPath), Paint(currentPaint)))
                }

                currentPath.reset()
                currentPoints.clear()
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun applyRulerSnap(point: PointF): PointF {
        val ruler = activeRuler ?: return point
        if (ruler.visibility != VISIBLE) return point

        val edge = ruler.getRulerEdgeLine()
        val dist = perpendicularDistance(point, edge.start, edge.end)
        
        if (dist < 35f) {
            return closestPointOnLine(point, edge.start, edge.end)
        }
        return point
    }

    private fun perpendicularDistance(p: PointF, lineStart: PointF, lineEnd: PointF): Float {
        val normalLength = hypot((lineEnd.x - lineStart.x).toDouble(), (lineEnd.y - lineStart.y).toDouble()).toFloat()
        if (normalLength == 0f) return hypot((p.x - lineStart.x).toDouble(), (p.y - lineStart.y).toDouble()).toFloat()
        val numerator = abs((lineEnd.y - lineStart.y) * p.x - (lineEnd.x - lineStart.x) * p.y + lineEnd.x * lineStart.y - lineEnd.y * lineStart.x)
        return numerator / normalLength
    }

    private fun closestPointOnLine(p: PointF, a: PointF, b: PointF): PointF {
        val apX = p.x - a.x
        val apY = p.y - a.y
        val abX = b.x - a.x
        val abY = b.y - a.y
        val ab2 = abX * abX + abY * abY
        if (ab2 == 0f) return a
        val t = ((apX * abX + apY * abY) / ab2).coerceIn(0f, 1f)
        return PointF(a.x + abX * t, a.y + abY * t)
    }

    private fun commitRecognizedShape(shape: ShapeRecognizer.RecognizedShape) {
        val finalPath = Path()

        when (shape) {
            is ShapeRecognizer.RecognizedShape.Line -> {
                finalPath.moveTo(shape.start.x, shape.start.y)
                finalPath.lineTo(shape.end.x, shape.end.y)
            }
            is ShapeRecognizer.RecognizedShape.Rectangle -> {
                finalPath.addRect(shape.left, shape.top, shape.right, shape.bottom, Path.Direction.CW)
            }
            is ShapeRecognizer.RecognizedShape.Circle -> {
                finalPath.addCircle(shape.centerX, shape.centerY, shape.radius, Path.Direction.CW)
            }
            is ShapeRecognizer.RecognizedShape.Freehand -> {
                finalPath.set(shape.path)
            }
        }

        pathsList.add(DrawElement(finalPath, Paint(currentPaint)))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (element in pathsList) {
            canvas.drawPath(element.path, element.paint)
        }
        if (!currentPath.isEmpty) {
            canvas.drawPath(currentPath, currentPaint)
        }
    }

    fun undo() {
        if (pathsList.isNotEmpty()) {
            redoList.add(pathsList.removeAt(pathsList.lastIndex))
            invalidate()
        }
    }

    fun redo() {
        if (redoList.isNotEmpty()) {
            pathsList.add(redoList.removeAt(redoList.lastIndex))
            invalidate()
        }
    }

    fun clearCanvas() {
        pathsList.clear()
        redoList.clear()
        currentPath.reset()
        currentPoints.clear()
        invalidate()
    }
}
