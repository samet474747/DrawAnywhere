package com.shezik.drawanywhere.ui.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import com.shezik.drawanywhere.ui.canvas.DrawingCanvasView
import com.shezik.drawanywhere.ui.overlay.FloatingToolbarView
import com.shezik.drawanywhere.ui.overlay.RulerOverlayView

class DrawingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var drawingCanvasView: DrawingCanvasView
    private var rulerView: RulerOverlayView? = null
    private var toolbarView: ComposeView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupDrawingCanvas()
        setupFloatingToolbar()
    }

    private fun getWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun setupDrawingCanvas() {
        drawingCanvasView = DrawingCanvasView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            getWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(drawingCanvasView, params)
    }

    private fun setupFloatingToolbar() {
        toolbarView = ComposeView(this).apply {
            setContent {
                FloatingToolbarView(
                    onSmartShapeToggled = { enabled ->
                        drawingCanvasView.isSmartShapeEnabled = enabled
                    },
                    onRulerToggled = { visible ->
                        if (visible) showRulerOverlay() else hideRulerOverlay()
                    },
                    onUndoClicked = { drawingCanvasView.undo() },
                    onClearClicked = { drawingCanvasView.clearCanvas() }
                )
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            getWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 100
        }

        windowManager.addView(toolbarView, params)
    }

    fun showRulerOverlay() {
        if (rulerView != null) return

        rulerView = RulerOverlayView(this)
        drawingCanvasView.activeRuler = rulerView

        val rulerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            getWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        windowManager.addView(rulerView, rulerParams)
    }

    fun hideRulerOverlay() {
        rulerView?.let {
            windowManager.removeView(it)
            rulerView = null
            drawingCanvasView.activeRuler = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hideRulerOverlay()
        toolbarView?.let { windowManager.removeView(it) }
        if (::drawingCanvasView.isInitialized) {
            windowManager.removeView(drawingCanvasView)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
