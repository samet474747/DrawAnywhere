# DrawAnywhere - Akıllı Şekiller ve Dijital Cetvel Eklenti Paketi

Bu paket, **DrawAnywhere** Android projesine **Akıllı Şekil Tanıma (Smart Shape Recognition)** ve **Dijital Cetvel (Digital Ruler with Snap-to-Edge)** özelliklerini doğrudan entegre etmeniz için hazırlanmış kaynak kod dosyalarını içerir.

## Paket İçeriği

1. `ui/canvas/ShapeRecognizer.kt`: Serbest el çizimlerini analiz ederek düz çizgi, dikdörtgen ve daireye dönüştüren geometrik tanıma algoritması.
2. `ui/canvas/DrawingCanvasView.kt`: `ShapeRecognizer` ve cetvel kenarına kilitleme (*snap-to-edge*) destekli çizim yüzeyi.
3. `ui/overlay/RulerOverlayView.kt`: Tek parmakla taşınabilen, iki parmakla döndürülebilen ölçekli dijital cetvel bileşeni.
4. `ui/overlay/FloatingToolbarView.kt`: Jetpack Compose tabanlı, Akıllı Şekil ve Cetvel modlarını açıp kapatan yüzer araç çubuğu.
5. `ui/service/DrawingOverlayService.kt`: Tüm katmanları `WindowManager` üzerinde yöneten arka plan servisi.

## Kurulum Adımları

1. ZIP içerisindeki `app/src/main/java/...` klasör yapısını mevcut **DrawAnywhere** Android Studio projenizin `app/src/main/java/` diziniyle birleştirin.
2. Jetpack Compose Material Icons Extended bağımlılığının (`androidx.compose.material:material-icons-extended`) `build.gradle.kts` dosyanızda ekli olduğundan emin olun (`AutoFixHigh` ve `Straighten` ikonları için gereklidir).
3. Projeyi derleyip cihazınızda çalıştırın.
